﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.IO.Ports; // Dont forget.

namespace Encender
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        string label;
        int cambio;
        SerialPort serialPort1 = new SerialPort(); //We create a new class



        public MainWindow()
        {
            // Configuramos el puerto serie.
            serialPort1.BaudRate = 115200; // Baudios. Tiene que ser el mismo al que usas de Arduino.
            serialPort1.PortName = "COM3"; // Port COM3, in my case is the one that use the Arduino in my Laptop.
            serialPort1.Parity = Parity.None; // Nada de paridad.
            serialPort1.DataBits = 8; // 8 Bits.
            serialPort1.StopBits = StopBits.Two; // Funciona mejor en 2 bits de Stop o parada.

            // Open the port while this application is Open.
            if (!serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Open();
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }          

        }

        
        private void ON_Click(object sender, RoutedEventArgs e)
        {
            byte[] mBuffer = Encoding.ASCII.GetBytes("Led_ON");
            serialPort1.Write(mBuffer, 0, mBuffer.Length);
        }

        private void OFF_Click(object sender, RoutedEventArgs e)
        {
            byte[] mBuffer = Encoding.ASCII.GetBytes("Led_OFF");
            serialPort1.Write(mBuffer, 0, mBuffer.Length);
        }

               

        private void txtInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            //Valor.Text = "The value of the position will be " + txtInput.Text + "?"; //Valor es la segunda caja

            label = txtInput.Text;
            cambio = Int32.Parse(label);

            if (cambio > 20)
            {
                byte[] mBuffer = Encoding.ASCII.GetBytes("Led_ON");
                serialPort1.Write(mBuffer, 0, mBuffer.Length);
            }
            else
            {
                byte[] mBuffer = Encoding.ASCII.GetBytes("Led_OFF");
                serialPort1.Write(mBuffer, 0, mBuffer.Length);
            }
        }

        private void btnSubmit_Checked(object sender, RoutedEventArgs e)
        {

        //    Valor.Text = txtInput.Text;
        //    label = txtInput.Text;
        //    cambio = Int32.Parse(label);

        //    //Aqui le movimos
        //    for (int i = 0; i < 10000; i++)
        //    {
        //        if (cambio > 20)
        //        {
        //            byte[] mBuffer = Encoding.ASCII.GetBytes("Led_ON");
        //            serialPort1.Write(mBuffer, 0, mBuffer.Length);
        //        }
        //        else
        //        {
        //            byte[] mBuffer = Encoding.ASCII.GetBytes("Led_OFF");
        //            serialPort1.Write(mBuffer, 0, mBuffer.Length);
        //        }
        //    }

        }
    }
}
