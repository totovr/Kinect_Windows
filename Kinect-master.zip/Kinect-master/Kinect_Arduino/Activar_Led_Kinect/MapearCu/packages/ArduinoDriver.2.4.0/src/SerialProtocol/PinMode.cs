﻿namespace ArduinoDriver.SerialProtocol
{
    public enum PinMode
    {
        Input,
        InputPullup,
        Output
    }
}
