﻿namespace ArduinoDriver.SerialProtocol
{
    public abstract class ArduinoMessage
    {
    }
}
