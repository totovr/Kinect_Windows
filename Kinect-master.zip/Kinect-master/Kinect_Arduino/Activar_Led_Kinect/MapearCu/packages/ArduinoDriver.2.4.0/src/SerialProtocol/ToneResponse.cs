﻿namespace ArduinoDriver.SerialProtocol
{
    public class ToneResponse : ArduinoResponse
    {
    }
}
