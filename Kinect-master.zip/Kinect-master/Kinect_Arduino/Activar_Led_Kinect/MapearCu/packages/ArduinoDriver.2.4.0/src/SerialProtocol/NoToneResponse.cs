﻿namespace ArduinoDriver.SerialProtocol
{
    public class NoToneResponse : ArduinoResponse
    {
    }
}
