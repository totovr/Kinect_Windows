﻿using RJCP.IO.Ports;

namespace ArduinoDriver.SerialEngines
{
    public class RJCPSerialPortStream : SerialPortStream, ISerialPortEngine
    {
    }
}
