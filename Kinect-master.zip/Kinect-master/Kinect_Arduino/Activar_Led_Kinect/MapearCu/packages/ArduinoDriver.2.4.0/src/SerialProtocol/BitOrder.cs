﻿namespace ArduinoDriver.SerialProtocol
{
    public enum BitOrder
    {
        LSBFIRST,
        MSBFIRST
    }
}
